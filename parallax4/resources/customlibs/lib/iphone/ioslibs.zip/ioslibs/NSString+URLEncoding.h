//
//  NSString+URLEncoding.h
//  VMAppWithKonylib
//
//  Created by Rajkumar Hasgul on 09/12/15.
//
//

#import <Foundation/Foundation.h>

@interface NSString (URLEncoding)
-(NSString *)urlEncodeUsingEncoding:(NSStringEncoding)encoding;
@end
